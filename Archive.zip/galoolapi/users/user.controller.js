const {
    create,
    login,
    userProfile,
    students,
    createStudent,
    updateStudent,
    createCourse,
    courses,
    updateCourse,
    studentEnrolledCourses,
    getVideos
}
    = require('./user.service');
const { sign } = require('jsonwebtoken')

module.exports = {
    create: (req, res) => {
        const body = req.body;
        create(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            return res.status(200).json(
                results[0][0])
        });
    },
    login: (req, res) => {
        const body = req.body;
        login(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            const result = results[0][0];
            if (result.code === '100') {
                const jsontoken = sign({ result: results }, "qwe123", {
                    expiresIn: '1h'
                })

                return res.status(200).json(
                    { ...result, userId: results[1][0].userId, token: jsontoken }
                )
            } else if (result.code === '101') {

                return res.status(200).json(
                    result
                )
            } else {
                return res.status(500).json(
                    results
                )
            }

        });
    },
    profile: (req, res) => {
        const body = req.body;
        userProfile(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            return res.status(200).json({
                userProfile: results[0][0],
                recentStudents: results[1],
                activeStudents: results[2][0].activeStudents,
                activeCourses: results[3][0].activeCourses
            })
        });
    },
    students: (req, res) => {
        const body = req.body;
        students(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            return res.status(200).json({
                students: results[0],
            })
        });
    },
    createStudent: (req, res) => {
        const body = req.body;
        getVideos(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            return res.status(200).json(
                results[0][0],
            )
        });
    },
    updateStudent: (req, res) => {
        const body = req.body;
        updateStudent(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            return res.status(200).json(
                results[0][0],
            )
        });
    },
    courses: (req, res) => {
        const body = req.body;
        courses(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            return res.status(200).json({
                courses: results[0],
            })
        });
    },
    createCourse: (req, res) => {
        const body = req.body;
        createCourse(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            return res.status(200).json(
                results[0][0],
            )
        });
    },
    updateCourse: (req, res) => {
        const body = req.body;
        updateCourse(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            return res.status(200).json(
                results[0][0],
            )
        });
    },
    studentEnrolledCourses: (req, res) => {
        const body = req.body;
        studentEnrolledCourses(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            console.log(results)
            const code = results[0][0].code;

            if (code === '100')
                return res.status(200).json({
                    code: results[0][0].code,
                    message: results[0][0].message,
                    enrolledCourses: results[1]
                })

            return res.status(200).json({
                code: results[0][0].code,
                message: results[0][0].message
            })
        });
    },
    getVideos: (req, res) => {
        const body = req.body;
        getVideos(body, (err, results) => {
            if (err) {
                console.log(err)
                return res.status(500).json({
                    success: 0,
                    message: err
                });
            }

            return res.status(200).json({
                videos: results[0],
            })
        });
    },
}