const pool = require('../../config/database');

module.exports = {
    create: (req, callBack) => {
        const sql = 'call user_register(?,?,?,?,?,?)';

        const values = [
            req.firstname,
            req.lastname,
            req.email,
            req.password,
            req. mobile,
            req.type
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
    login: (req, callBack) => {

        const sql = 'call sp__ga_user_login(?,?)';

        const values = [
            req.email,
            req.password
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
    userProfile: (req, callBack) => {

        const sql = 'call userprofile(?)';

        const values = [
            req.userid,
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
    students: (req, callBack) => {

        const sql = 'call sp_thub_students(?)';

        const values = [
            req.userid,
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
    createStudent: (req, callBack) => {

        const sql = 'call sp_thub_create_student(?,?,?,?,?,?,?,?,?,?)';

        const values = [
            req.userId,
            req.firstname,
            req.lastname,
            req.email,
            req.mobile,
            req. courseId,
            req.shift,
            req.classstatus,
            req.gender,
            req.city
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
    updateStudent: (req, callBack) => {

        const sql = 'call sp_thub_update_student(?,?,?,?,?,?,?,?)';
        

        const values = [
            req.userId,
            req.studentId,
            req.firstname,
            req.lastname,
            req.email,
            req.mobile,
            req. courseId,
            req.shift
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
    courses: (req, callBack) => {

        const sql = 'call sp_ga_courses(?)';
        

        const values = [
            req.userId,
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
    createCourse: (req, callBack) => {

        const sql = 'call sp_thub_create_course(?,?,?,?,?)';
        

        const values = [
            req.userId,
            req.coursename,
            req.coursefee,
            req.startdate,
            req.enddate
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
    updateCourse: (req, callBack) => {

        const sql = 'call sp_thub_update_course(?,?,?,?,?,?)';
        

        const values = [
            req.userId,
            req.courseId,
            req.coursename,
            req.coursefee,
            req.startdate,
            req.enddate
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
    studentEnrolledCourses: (req, callBack) => {

        const sql = 'call sp_ga_student_courses(?)';

        const values = [
            req.userId
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
    getVideos: (req, callBack) => {

        const sql = 'call sp_ga_videos(?)';

        const values = [
            req.courseId
        ]
        pool.query(sql, values, (error, result) => {
            if (error)
                callBack(error)
            return callBack(null, result)
        })
    },
}